---
description: Create prompt queue files (_PROMPTS_[NN]-[Topic].md) for sequential headless execution
auto_execution_mode: 3
---

# Write Prompts Workflow

Create `_PROMPTS_[NN]-[Topic].md` files containing an ordered list of prompts. Each prompt is a fenced code block. Prompts execute sequentially as turns of ONE session.

**Goal**: Validated `_PROMPTS_[NN]-[Topic].md` file with focused, verifiable prompts

**Why**: Headless prompts must be complete on first submission - no human correction loop

## Required Skills

- @skills:write-documents `PROMPTS_TEMPLATE.md` for file skeleton (copy and fill)
- @skills:write-documents `PROMPTS_GUIDES.md` for strategic approach (read BEFORE writing)
- @skills:write-documents `PROMPTS_RULES.md` for output verification (PRMT-* rules)
- @skills:write-documents `PROMPTS_ROBUSTNESS_GUIDES.md` for hang-prevention clause template and inter-prompt problem filing
- @skills:llm-tools `MODEL_INVENTORY.md` for model data (read BEFORE partitioning)
- @skills:terminal-robustness for hang mechanisms, safe command patterns, and robustness card templates (agent variants: ClaudeCode minimum, DevinCascade full findings)

## MUST-NOT-FORGET

- Final message starts with `Deliverables`: clickable workspace-relative paths (backticked, forward slashes) of main output files + short purpose (`agent-behavior.md` Deliverables first)
- First non-empty line MUST be an opening fence, Commentary (heading/notes), or optional Execution Frontmatter (per PRMT-FT-08). No other YAML frontmatter.
- Optional Execution Frontmatter (PRMT-FT-08): YAML block at file start with `intended_model`, `context_window_size`, `effort`, `prompt_system`. Execution engine MAY honor or override. Omit if no hints needed.
- Fence length: 3-9 backticks per prompt. Outer fence MUST exceed deepest inner fence
- `---` separator between every pair of consecutive prompts
- Commentary (headings, notes) only between `---` and next fence - never sent to model. Commentary notes MUST be in HTML comments (`<!-- ... -->`), headings as plain Markdown
- Heading recommendation (PRMT-FT-07): use `## Prompt N - [title]` before each prompt. If headings are used, ALL prompts MUST have headings
- Prompt Marker (PRMT-FT-10): all prompt sequences MUST include a file identifier prefix `[NN]-[Topic] [ NN / NN ]` as first line inside each prompt's fence, where `[NN]-[Topic]` is derived from the filename `_PROMPTS_[NN]-[Topic].md`. Not in the heading. When using a planning document (PRMT-SC-06), marker includes plan summary: `[NN]-[Topic] [ NN / NN ] - [plan step ID] [brief summary]`
- At least one prompt per file
- **NEVER modify tracking documents** (PROGRESS.md, PROBLEMS.md, NOTES.md, FAILS.md). Write-* workflows create NEW files only.
- Pre-Write Privacy Gate (`agent-behavior.md`): General-purpose documents → all content generic. ILLUSTRATIVE content → examples generic.
- **Rule precedence**: PRMT-CT-04 (objectives not steps) overrides PRMT-CT-05 (precision). See PRMT-CT-04 for details.
- **Workflow references** (PRMT-CT-10): When a workflow appears in prompt prose as a reference (no execution verb, no execution requirement), wrap in backticks (`/write-prompts`). When calling a workflow to execute (execution verb present: run, use, execute, call, invoke, perform, apply, do), use a standalone line with the slash command without backticks (PRMT-CT-08). Execution verb + backticks = violation.
- **Leverage existing workflows** (PRMT-CT-11): Before writing prompts, scan `[AGENT_FOLDER]/workflows/` frontmatters to find workflows relevant to the task. Load matching workflows entirely. Design prompts that reference or invoke existing workflows instead of reinventing their logic in prompt prose. If user explicitly requests prompt system independence, omit `prompt_system` from frontmatter (PRMT-FT-09) and do not reference workflows.
- **NEVER self-execute prompt files** (PRMT-EX-02): After writing a prompt file, deliver it to the user or execution engine. Do NOT run all prompts in a single response. Each prompt is a separate turn for an execution engine (Lana, headless runner). Self-executing circumvents per-turn context engineering and compute allocation, defeating the purpose of prompt files.
- **Execution authority** (PRMT-EX-03): Prompts in `_PROMPTS_*.md` files carry implicit execution authority. Agent must complete without asking for confirmation. Confirmation pauses hang the sequence.
- **Session Anchor** (PRMT-SC-08): Every prompt must declare absolute session folder and working folder after the Prompt Marker. Implementation prompts include "All file operations MUST stay within the declared working folder unless an absolute path outside it is explicitly named in this prompt" as first constraint. `/write-prompts` resolves both paths from the current session context at write time.
- **Self-contained prompts** (PRMT-SC-01): Every prompt must start with a context-loading directive, "treat earlier conversation as compacted" statement, and step identifier. No prompt may reference "the previous step" without naming where output lives in a file (PRMT-SC-02).
- **Idempotency constraints** (PRMT-SC-03): Implementation prompts must include "re-running this prompt must not corrupt state or waste cost" in constraints.
- **Chain length limit** (PRMT-SC-04): Max 10 implementation prompts per file (verification checkpoints do not count). Longer sequences continue in the next numbered prompts file.
- **Effort-based partitioning** (PRMT-SC-05): Frontmatter must specify `effort` level. Prompt count must match effort budget (low effort = more tightly scoped prompts, high effort = fewer broader prompts). Take `context_window_size`, supported effort levels, Depth, Items, and Notes (scope guard) from `MODEL_INVENTORY.md`. See `PROMPTS_GUIDES.md` Sections 1c and 1g.
- **Planning document anchor** (PRMT-SC-06): Prompt sequences from planning documents (TASKS, STRUT) must reference the document by filename and step ID. See `PROMPTS_GUIDES.md` Section 1d.
- **Load-based workflow partitioning** (PRMT-SC-07): Prompts invoking workflows must group invocations by assessed load against the run budget. See `PROMPTS_GUIDES.md` Section 1f for the assessment procedure.
- **Hang-safety clause** (PRMT-HS-01): Every implementation prompt MUST include the one-line hang-safety clause in Constraints, referencing `agent-behavior.md` Terminal Hang Prevention and the project robustness card (bans, expected runtimes); never restate monitoring, hang-verdict, or kill procedures, and never give a command a time limit. If no card exists, create one from the agent's `ROBUSTNESS_CARD_TEMPLATE.md` (@skills:terminal-robustness). Clause template: `PROMPTS_ROBUSTNESS_GUIDES.md` Section 2.
- **Runtime check and Fails card** (PRMT-RB-08): Reuse the working folder's `_agentwork/__CARD_[TOPIC]-Fails.md`, else create it from the Fails block of `ROBUSTNESS_CARD_SKELETON.md`. Every implementation prompt carries exactly one `Runtime check:` line (template: `PROMPTS_ROBUSTNESS_GUIDES.md` Section 2b).
- **Agent tool limits** (PRMT-HS-11): You (the writer) are assumed to be the executor. Copy your agent-specific rule file, section Tool-Call Payload Limit (if absent, `tools-and-skills.md` Large File Writes), verbatim into the robustness card `## Agent tool limits`. File-writing prompts reference the card; never restate token numbers. See `PROMPTS_ROBUSTNESS_GUIDES.md` Section 2a.
- **Verification specificity** (PRMT-HS-07): Verification sections must name specific test files when code changes affect tests, include residual sweeps when concepts are removed, and confirm prior steps when dependencies exist.
- **Prior-step verification** (PRMT-HS-08): Dependent prompts must verify the prior step is done before proceeding.
- **Agent tools over shell** (PRMT-CT-12): Prompt bodies and Verify sections use agent tool directives (grep_search, read_file, find_by_name, code_search) for file search/read, not shell commands. Outside the workspace: `rg.exe` inside a tmp script through the supervised runner, never inline.
- **Targeted test scope** (PRMT-HS-09): Verification must run specific test files during implementation, not the full suite. Full suite only in final verification.
- **Interleaved verification** (PRMT-SQ-04): Insert a verification prompt after every checkpoint interval (Items 8: every 3 implementation prompts, Items 6: every 2, Items 5 or less: every prompt) plus a final checkpoint per file. Verification prompts run `/verify` against the planning document and `/fix` for gaps. They do NOT count toward the 10 implementation prompts per file.

## Context Branching

This workflow has two modes. Determine the mode from the user's request:

- **Compose mode** (default) - Write prompts from scratch based on user description
  - Trigger: `/write-prompts [description]`
  - Steps: classify task, decompose, write, verify

- **From Template mode** - Generate a filled prompts file from a `_PROMPTS_*_TEMPLATE.md`
  - Trigger: `/write-prompts from template [path/to/template]`
  - Steps: read template, collect placeholder values, generate filled instance, verify
  - The template's top comment block contains the placeholder registry and usage instructions
  - Output: `_PROMPTS_[NN]-[Topic]-[Instance].md` following the template's naming convention

## Prerequisites

### Compose mode

- User has described one or more prompts to execute sequentially
- Determine if prompts contain code blocks (affects fence length)

### From Template mode

- User has provided a path to a `_PROMPTS_*_TEMPLATE.md` file
- User has provided (or can provide) case-specific context for placeholder values

# COMPOSE MODE

## Step 1: Read PROMPTS_GUIDES.md and Scan Existing Workflows

Read `PROMPTS_GUIDES.md` from @skills:write-documents. Classify the task, decide decomposition, plan state flow between prompts.

**Hang-safety planning**: Read `PROMPTS_ROBUSTNESS_GUIDES.md` from @skills:write-documents for the clause template. Then load @skills:terminal-robustness (agent variant per SKILL.md dispatch). If a robustness card (`_agentwork/__CARD_*-Robustness.md`) exists, build the hang-safety clause from its banned list and expected runtimes. If not, copy the agent's `ROBUSTNESS_CARD_TEMPLATE.md` to `_agentwork/__CARD_[TOPIC]-Robustness.md` of the current working folder, extend it with project-specific entries (commands that wait on stdin, launch pagers, run unbounded children), and use it. The clause references the card by filename instead of repeating the full list. Copy your own Tool-Call Payload Limit section verbatim into the card `## Agent tool limits` (PRMT-HS-11); on an existing card, refresh that section from the rule.

**Fails-card planning**: Reuse `_agentwork/__CARD_[TOPIC]-Fails.md` of the working folder if it exists (earlier sequences and chat tasks recorded there); else create it from the Fails block of `ROBUSTNESS_CARD_SKELETON.md` (empty "Never again" list, no entries). Every implementation prompt carries the `Runtime check:` line naming this card. The final checkpoint of each prompts file promotes its "Never again" lines to the robustness card banned list.

**Findings-card planning**: Designate a `_agentwork/__CARD_[TOPIC]-Findings.md` card for the sequence. Every implementation prompt includes a `Findings card:` directive pointing to this card. The card is loaded at prompt startup and updated at end-of-prompt with content glitches, spec-code mismatches, and unexpected findings (command failures go to the Fails card). Session PROBLEMS.md records problems that must be approached later (blockers, prompts stopped by a repeated failure, deferred issues).

**Effort-based partitioning**: Read the frontmatter `effort` level (PRMT-SC-05). Scope prompts to the effort budget: at low effort, each prompt handles one file or one edit; at high effort, a single prompt can handle multi-file analysis and implementation. Match prompt count to effort level. See `PROMPTS_GUIDES.md` Section 1c.

**Model-aware partitioning**: Follow `PROMPTS_GUIDES.md` Section 1g with the `MODEL_INVENTORY.md` row of `intended_model` (PRMT-SC-05).

**Workflow load assessment**: Assess workflow invocations and group them into prompts by load against the run budget. Follow `PROMPTS_GUIDES.md` Section 1f (PRMT-SC-07). State the grouping rationale in the sub-chain commentary.

**Planning document check**: Verify a TASKS or STRUT planning document exists for the task. If it exists, reference it by filename and step ID in each prompt's self-contained opening (PRMT-SC-06). If no planning document exists, the prompt file itself serves as the tracking document. See `PROMPTS_GUIDES.md` Section 1d.

Then scan `[AGENT_FOLDER]/workflows/` frontmatters (the `description` field) to find workflows relevant to the task. Load matching workflows entirely to understand their structure, steps, and dispatch patterns before designing prompts (PRMT-CT-11). Design prompts that reference or invoke these workflows instead of reinventing their logic.

## Step 2: Determine File Location and Name

- Filename: `_PROMPTS_[NN]-[Topic].md`
- `[NN]` = zero-padded 2-digit sequence number starting at `01` (PRMT-NM-03). When creating multiple files in one invocation, assign sequential numbers. When adding to a folder with existing prompt files, continue from the highest existing number + 1
- `[Topic]` = `[DomainShort]-[Purpose]` where DomainShort is 2-8 CamelCase chars abbreviated from the STRUT topic or approach name (PRMT-NM-04), and Purpose is a short CamelCase description of what the prompts do (max 20 chars). Total topic under 30 chars. [NN]-[Topic] must be unique across all _PROMPTS_*.md files in the session
- Location: `_agentwork/` of the current working folder (session root, `T##_*`, `S##_*`, or run folder; `[WORKSPACE_FOLDER]/_agentwork/` in PROJECT-MODE) per `agent-behavior.md` File Placement, or a user-specified path. Exception: reusable `_PROMPTS_*_TEMPLATE.md` files are deliverables and stay beside the documents they serve
- Examples: `_PROMPTS_01-WlSeg-Preflight.md`, `_PROMPTS_05-WlSeg-S1-Inheritors.md`, `_PROMPTS_01-Mmnts-Preflight.md`

## Step 3: Select Fence Length Per Prompt

For each prompt, find the deepest inner fence and set the outer fence one longer.

- Prompt has no code blocks → 3 backticks
- Prompt contains ``` blocks → 4+ backtick outer fence
- Prompt contains ```` blocks (e.g. markdown examples with ``` inside) → 5+ backtick outer fence
- Maximum outer fence: 9 backticks. If deeper nesting needed, restructure the prompt.

## Step 4: Write Prompts File

**Format overview** (5-prompt example with interleaved verification, optional frontmatter and headings, per PRMT-FT-07/08, PRMT-SQ-04):

`````markdown
---
intended_model: claude-sonnet-4-5
context_window_size: 200k
effort: high
prompt_system: IPPS
---

## Prompt 1 - Setup

```
[NN]-[Topic] [ 01 / 07 ] - [plan step ID] [brief summary]

Session: `[ABSOLUTE_SESSION_FOLDER_PATH]`
Working folder: `[ABSOLUTE_WORKING_FOLDER_PATH]`

Read [context-loading directive: files to read]. Treat earlier conversation as compacted. Step [step identifier].
Planning document: [TASKS or STRUT filename], step [ID].

First prompt text. Plain instruction, no code blocks inside.

Constraints:
- All file operations MUST stay within the declared working folder unless an absolute path outside it is explicitly named in this prompt
- [What NOT to do]
- Execute without asking for confirmation
- Re-running this prompt must not corrupt state or waste cost
- Hang safety: commands per `agent-behavior.md` Terminal Hang Prevention (supervised runner); bans and expected runtimes per `_agentwork/__CARD_[TOPIC]-Robustness.md`.
- Runtime check: before each command state the expected seconds and check the "Never again" list in `_agentwork/__CARD_[TOPIC]-Fails.md`; while it runs read the `ALIVE` lines in the runner log and end it only on a hang verdict, never for its runtime; after it compare with `elapsed=`; on KILLED, ERROR, unexpected exit, or elapsed above both 3x expected and expected + 30 s, write a Fails card entry at once, fix the root cause, continue (a finished slow command is never re-run); same failure twice in this prompt: stop with a PROBLEMS.md entry naming the Fails entry ID.

Verify: [Machine-checkable done criteria]
```

---

## Prompt 2 - Implement Core

<!-- Optional notes explaining the next prompt's purpose. -->

````
[NN]-[Topic] [ 02 / 07 ] - [plan step ID] [brief summary]

Session: `[ABSOLUTE_SESSION_FOLDER_PATH]`
Working folder: `[ABSOLUTE_WORKING_FOLDER_PATH]`

Read [context-loading directive: files to read]. Treat earlier conversation as compacted. Step [step identifier].
Planning document: [TASKS or STRUT filename], step [ID].

Second prompt with a code block inside:
```python
print("hello")
```

Constraints:
- All file operations MUST stay within the declared working folder unless an absolute path outside it is explicitly named in this prompt
- [What NOT to do]
- Execute without asking for confirmation
- Re-running this prompt must not corrupt state or waste cost
- Hang safety: commands per `agent-behavior.md` Terminal Hang Prevention (supervised runner); bans and expected runtimes per `_agentwork/__CARD_[TOPIC]-Robustness.md`.
- Runtime check: before each command state the expected seconds and check the "Never again" list in `_agentwork/__CARD_[TOPIC]-Fails.md`; while it runs read the `ALIVE` lines in the runner log and end it only on a hang verdict, never for its runtime; after it compare with `elapsed=`; on KILLED, ERROR, unexpected exit, or elapsed above both 3x expected and expected + 30 s, write a Fails card entry at once, fix the root cause, continue (a finished slow command is never re-run); same failure twice in this prompt: stop with a PROBLEMS.md entry naming the Fails entry ID.

Verify: [Observable success criteria]
````

---

## Verification Checkpoint 1

<!-- Verify prompts 1-2 against STRUT before continuing. -->

```
[NN]-[Topic] [ 03 / 07 ] - Verification checkpoint after prompts 1-2

Session: `[ABSOLUTE_SESSION_FOLDER_PATH]`
Working folder: `[ABSOLUTE_WORKING_FOLDER_PATH]`

Read [rules card] and [STRUT filename]. Treat earlier conversation as compacted. Verification checkpoint after prompts 1-2.

/verify

current state against [STRUT filename] for prompts executed so far.

/fix

all gaps and remaining work.
```

---

## Prompt 3 - Implement Next Feature

```
[NN]-[Topic] [ 04 / 07 ] - [plan step ID] [brief summary]

Session: `[ABSOLUTE_SESSION_FOLDER_PATH]`
Working folder: `[ABSOLUTE_WORKING_FOLDER_PATH]`

Read [context-loading directive: files to read]. Treat earlier conversation as compacted. Step [step identifier].
Planning document: [TASKS or STRUT filename], step [ID].

Third implementation prompt.

Constraints:
- All file operations MUST stay within the declared working folder unless an absolute path outside it is explicitly named in this prompt
- [What NOT to do]
- Execute without asking for confirmation
- Re-running this prompt must not corrupt state or waste cost
- Hang safety: commands per `agent-behavior.md` Terminal Hang Prevention (supervised runner); bans and expected runtimes per `_agentwork/__CARD_[TOPIC]-Robustness.md`.
- Runtime check: before each command state the expected seconds and check the "Never again" list in `_agentwork/__CARD_[TOPIC]-Fails.md`; while it runs read the `ALIVE` lines in the runner log and end it only on a hang verdict, never for its runtime; after it compare with `elapsed=`; on KILLED, ERROR, unexpected exit, or elapsed above both 3x expected and expected + 30 s, write a Fails card entry at once, fix the root cause, continue (a finished slow command is never re-run); same failure twice in this prompt: stop with a PROBLEMS.md entry naming the Fails entry ID.

Verify: [Machine-checkable done criteria]
```

---

## Prompt 4 - Finalize

```
[NN]-[Topic] [ 05 / 07 ] - [plan step ID] [brief summary]

Session: `[ABSOLUTE_SESSION_FOLDER_PATH]`
Working folder: `[ABSOLUTE_WORKING_FOLDER_PATH]`

Read [context-loading directive: files to read]. Treat earlier conversation as compacted. Step [step identifier].
Planning document: [TASKS or STRUT filename], step [ID].

Fourth implementation prompt.

Constraints:
- All file operations MUST stay within the declared working folder unless an absolute path outside it is explicitly named in this prompt
- [What NOT to do]
- Execute without asking for confirmation
- Re-running this prompt must not corrupt state or waste cost
- Hang safety: commands per `agent-behavior.md` Terminal Hang Prevention (supervised runner); bans and expected runtimes per `_agentwork/__CARD_[TOPIC]-Robustness.md`.
- Runtime check: before each command state the expected seconds and check the "Never again" list in `_agentwork/__CARD_[TOPIC]-Fails.md`; while it runs read the `ALIVE` lines in the runner log and end it only on a hang verdict, never for its runtime; after it compare with `elapsed=`; on KILLED, ERROR, unexpected exit, or elapsed above both 3x expected and expected + 30 s, write a Fails card entry at once, fix the root cause, continue (a finished slow command is never re-run); same failure twice in this prompt: stop with a PROBLEMS.md entry naming the Fails entry ID.

Verify: [Machine-checkable done criteria]
```

---

## Verification Checkpoint 2

<!-- Verify prompts 3-4 against STRUT before final prompt. -->

```
[NN]-[Topic] [ 06 / 07 ] - Verification checkpoint after prompts 3-4

Session: `[ABSOLUTE_SESSION_FOLDER_PATH]`
Working folder: `[ABSOLUTE_WORKING_FOLDER_PATH]`

Read [rules card] and [STRUT filename]. Treat earlier conversation as compacted. Verification checkpoint after prompts 3-4.

/verify

current state against [STRUT filename] for prompts executed so far.

/fix

all gaps and remaining work.
```

---

## Prompt 5 - Final Verification

```
[NN]-[Topic] [ 07 / 07 ] - [plan step ID] [brief summary]

Session: `[ABSOLUTE_SESSION_FOLDER_PATH]`
Working folder: `[ABSOLUTE_WORKING_FOLDER_PATH]`

Read [context-loading directive: files to read]. Treat earlier conversation as compacted. Step [step identifier].
Planning document: [TASKS or STRUT filename], step [ID].

Final verification prompt. Run the full test suite to confirm no regressions.

Constraints:
- All file operations MUST stay within the declared working folder unless an absolute path outside it is explicitly named in this prompt
- Execute without asking for confirmation
- Re-running this prompt must not corrupt state or waste cost
- Hang safety: commands per `agent-behavior.md` Terminal Hang Prevention (supervised runner); bans and expected runtimes per `_agentwork/__CARD_[TOPIC]-Robustness.md`.
- Runtime check: before each command state the expected seconds and check the "Never again" list in `_agentwork/__CARD_[TOPIC]-Fails.md`; while it runs read the `ALIVE` lines in the runner log and end it only on a hang verdict, never for its runtime; after it compare with `elapsed=`; on KILLED, ERROR, unexpected exit, or elapsed above both 3x expected and expected + 30 s, write a Fails card entry at once, fix the root cause, continue (a finished slow command is never re-run); same failure twice in this prompt: stop with a PROBLEMS.md entry naming the Fails entry ID.

Verify: Run `bun test --timeout 20000` (per-test timeout; expected runtime of the full suite from the robustness card). All tests pass.
```
`````

**Format rules:**
1. First non-empty line = optional Execution Frontmatter (per PRMT-FT-08), Commentary (heading/notes), or opening fence. No other YAML frontmatter
2. Each prompt = opening fence + prompt text + closing fence
3. Closing fence = line with >= N backticks (where N = opening fence length)
4. `---` on its own line between consecutive prompts
5. Commentary (headings, paragraphs, lists) allowed before the first prompt and between `---` and next opening fence. Commentary notes MUST be in HTML comments (`<!-- ... -->`), headings as plain Markdown
6. Heading recommendation (PRMT-FT-07): use `## Prompt N - [title]` before each prompt. If headings are used, ALL prompts MUST have headings
7. Prompt Marker (PRMT-FT-10): all prompt sequences MUST include a file identifier prefix `[NN]-[Topic] [ NN / NN ]` as first line inside each prompt's fence, where `[NN]-[Topic]` is derived from the filename `_PROMPTS_[NN]-[Topic].md`. When using a planning document (PRMT-SC-06), marker includes plan summary: `[NN]-[Topic] [ NN / NN ] - [plan step ID] [brief summary]`
8. Info string after opening fence (e.g. `` ```text ``) is optional and ignored by executor
9. Prompts execute in file order
10. Execution Frontmatter is required for multi-prompt files (PRMT-SC-05); omit only for single-prompt, model-agnostic files
11. Verification prompts (PRMT-SQ-04): checkpoint after every checkpoint interval from the Items value (Items 8: 3, Items 6: 2, Items 5 or less: 1) plus a final checkpoint per file. Use heading `## Verification Checkpoint N`. Verification prompts do NOT count toward the 10 implementation prompts per file (PRMT-SC-04)

## Step 4a: Insert Verification Checkpoints

Insert verification checkpoints after every checkpoint interval plus a final checkpoint per file (PRMT-SQ-04, `PROMPTS_GUIDES.md` Section 1g step 6):

1. Count implementation prompts (exclude verification prompts from the count)
2. Insert a `## Verification Checkpoint N` prompt after every checkpoint interval (Items 8: 3 implementation prompts, Items 6: 2, Items 5 or less: 1) and after the last implementation prompt
3. Each checkpoint runs `/verify` against the planning document and `/fix` for gaps
4. Verification prompts are self-contained (PRMT-SC-01): read rules card and planning document
5. Verification prompts do NOT count toward the 10 implementation prompts per file (PRMT-SC-04)
6. Use `## Verification Checkpoint N` heading (not `## Prompt N`) to distinguish from implementation prompts

**Checkpoint placement examples**:
- 3 implementation prompts, Items 8: final checkpoint only
- 5 implementation prompts, Items 6: checkpoints after prompt 2, after prompt 4, final after prompt 5
- 9 implementation prompts, Items 5: checkpoint after every prompt (9 checkpoints, 18 prompts in one file)

**Checkpoint prompt template**:
```
[NN]-[Topic] [ NN / NN ] - Verification Checkpoint [N]

Session: `[ABSOLUTE_SESSION_FOLDER_PATH]`
Working folder: `[ABSOLUTE_WORKING_FOLDER_PATH]`

Read [rules card] and [STRUT filename]. Treat earlier conversation as compacted. Verification checkpoint after prompts [N]-[M].

/verify

current state against [STRUT filename] for prompts executed so far.

/fix

all gaps and remaining work.
```

**Final checkpoint promotion** (PRMT-SQ-04): Before the STOP instruction, the final checkpoint carries one line: `Promote the "Never again" lines of _agentwork/__CARD_[TOPIC]-Fails.md to the banned list of _agentwork/__CARD_[TOPIC]-Robustness.md (Fails card rules: ROBUSTNESS_CARD_SKELETON.md).`

**Final checkpoint STOP directive** (PRMT-SQ-05): The final checkpoint of every prompt sequence file MUST conclude with a STOP instruction requiring a clickable summary artifact list with multiple headings for each output group (do not wrap in code fences):
```
**STOP.** Report: final run status, items completed, and a clickable summary artifact list with separate headings for each output group, where each group contains: heading, summary of what was done and what the files contain, and bulleted clickable file paths with file purpose/content (- `relative/path/to/file` - <description>). Do not wrap the list in code fences, and never use file:/// links or raw HTML.
```

## Step 5: Verify

Check output against all PRMT-* rules in `PROMPTS_RULES.md`:

- [ ] Format (FT): PRMT-FT-01 through PRMT-FT-10
- [ ] Structure (ST): PRMT-ST-01 through PRMT-ST-05
- [ ] Sequence (SQ): PRMT-SQ-01 through PRMT-SQ-05
- [ ] Content (CT): PRMT-CT-01 through PRMT-CT-14
- [ ] Self-Contained (SC): PRMT-SC-01 (self-contained opening), PRMT-SC-02 (no conversation dependency), PRMT-SC-03 (idempotency constraint), PRMT-SC-04 (max 10 implementation prompts per file), PRMT-SC-05 (effort and model specification, model-data checks against the `MODEL_INVENTORY.md` row), PRMT-SC-06 (planning document reference), PRMT-SC-08 (session anchor with absolute paths)
- [ ] Execution (EX): PRMT-EX-01 (one prompt per turn), PRMT-EX-02 (no self-execution), PRMT-EX-03 (execution authority)
- [ ] Hang Safety (HS): PRMT-HS-01 through PRMT-HS-11
- [ ] Robustness (RB): PRMT-RB-01 through PRMT-RB-08 (findings card designated, directive in every implementation prompt, card read at startup, glitches filed before commit, entry format, card system integration, PROBLEMS.md distinction, Fails card + one runtime-check line per implementation prompt)
- [ ] Naming (NM): PRMT-NM-01 (filename pattern `_PROMPTS_[NN]-[Topic].md`), PRMT-NM-02 (Topic describes purpose), PRMT-NM-03 ([NN] zero-padded sequence number), PRMT-NM-04 (Topic contains domain prefix ensuring [NN]-[Topic] uniqueness across session; topic under 30 chars)

### Step 5b: Workflow Call Formatting Pass

Scan every fenced prompt for workflow names (patterns matching `/[a-z-]+`). For each occurrence:

1. Standalone line without backticks, slash command alone with arguments on following line(s) → OK (execution, PRMT-CT-08)
2. Backticks in prose, NO execution verb → OK (reference, PRMT-CT-10)
3. Backticks in prose, WITH execution verb (run, use, execute, call, invoke, perform, apply, do) → VIOLATION: rewrite as standalone line without backticks, arguments on next line

Execution verbs: run, use, execute, call, invoke, perform, apply, do

Example fix:
- BAD: "Use the `/sync` workflow to sync files."
- GOOD: "Sync files:" + standalone `/sync` line + arguments on next line

### Step 5c: Self-Contained Opening Pass

Scan every fenced prompt for the self-contained opening (PRMT-SC-01). Each prompt must contain:

1. A context-loading directive naming files or cards to read
2. "Treat earlier conversation as compacted" statement
3. A step identifier (STRUT step, task ID, or sequence position)

If any prompt is missing any of the three elements, add them. Check that no prompt references "the previous step" or "as discussed above" without naming where the output lives in a file (PRMT-SC-02).

### Step 5d: Tool Preference and Test Scope Pass

Scan every fenced prompt for shell commands used for file operations and full-suite test runs:

1. **Tool preference** (PRMT-CT-12): Scan prompt bodies (excluding Verify sections) for shell file-operation commands: `Select-String`, `Get-ChildItem`, `Get-Content`, `cat`, `grep`, `find`, `rg.exe`. If found outside Verify sections, rewrite as agent tool directives ("Search for X using the grep_search tool", "Read `file.ts`", "Find all .ts files using the find_by_name tool").
2. **Test scope** (PRMT-HS-09): Scan Verify sections for bare `bun test`, `npm test`, or equivalent full-suite commands in implementation prompts. If found, replace with specific test file paths. Full suite is acceptable only in a prompt explicitly marked as final verification.

### Step 5e: Interleaved Verification Pass

Check whether the sequence needs interleaved verification prompts (PRMT-SQ-04):

1. Count implementation prompts (exclude verification prompts from the count)
2. Check for `## Verification Checkpoint N` headings containing `/verify` and `/fix` workflow calls after every checkpoint interval and after the last implementation prompt
3. If missing: insert verification checkpoints using the template from Step 4a
4. Verify checkpoint prompts are self-contained (PRMT-SC-01), do NOT count toward the 10 implementation prompts per file (PRMT-SC-04), and use `## Verification Checkpoint N` heading (not `## Prompt N`)

### Step 5f: Session Anchor Pass

Scan every fenced prompt for the Session Anchor (PRMT-SC-08):

1. Each prompt must contain a `Session:` line and a `Working folder:` line with absolute paths
2. The anchor must be placed after the Prompt Marker and empty line, before the context-loading directive
3. Paths must be absolute (start with drive letter on Windows, `/` on Unix) - relative paths are a violation
4. If no subfolder is active, working folder must equal the session folder
5. Implementation prompts must include "All file operations MUST stay within the declared working folder unless an absolute path outside it is explicitly named in this prompt" as first constraint

If any prompt is missing the anchor or uses relative paths, add the anchor with absolute paths resolved from the current session context.

# FROM TEMPLATE MODE

## Step T1: Read Template

Read the `_PROMPTS_*_TEMPLATE.md` file specified by the user. Extract:

1. **Placeholder registry** from the top comment block - list of all `[PLACEHOLDER]` values with descriptions
2. **Instance naming convention** - how the filled file should be named
3. **Usage instructions** - any special filling rules
4. **Conditional sections** - prompts or sections marked `<!-- Conditional: ... -->` that may be included or removed based on context

## Step T2: Collect Placeholder Values

For each placeholder in the registry:

1. Check if the user provided the value in their request or conversation history
2. If not provided: derive from context (session files, PROBLEMS.md, SPEC, IMPL) by reading the referenced files
3. If not derivable: list the missing placeholders and their descriptions - the user must provide them
4. Do not guess placeholder values. Every value must be sourced from user input or workspace files.

## Step T3: Generate Filled Instance

1. Copy the template content
2. Remove ALL XML comments (template annotations are not part of the output)
3. Replace ALL `[PLACEHOLDER]` values with the collected case-specific data
4. Resolve conditional sections: remove the branch that does not apply based on the collected values (e.g., remove BUG pipeline when category = CHANGE)
5. Verify fence depths are still correct after modifications (PRMT-FT-02)
6. Save as `_PROMPTS_[NN]-[Topic]-[Instance].md` following the template's naming convention

## Step T4: Verify Filled Instance

The filled file must pass all PRMT-* rules as a standalone prompts file:

- [ ] PRMT-FT-01: First non-empty line is optional frontmatter (PRMT-FT-08), Commentary, or opening fence
- [ ] PRMT-FT-02: Fence lengths correct (outer > deepest inner)
- [ ] PRMT-FT-03: `---` separator between every pair of consecutive prompts
- [ ] PRMT-FT-04: Commentary notes in HTML comments (`<!-- ... -->`), headings as plain Markdown, only between separator and next fence (or before first fence)
- [ ] PRMT-FT-07: If headings are used, all prompts have headings (MUST)
- [ ] PRMT-FT-08: If frontmatter present, it is at file start with valid keys
- [ ] PRMT-FT-10: Each prompt includes a file identifier prefix `[NN]-[Topic] [ NN / NN ]` Prompt Marker as first line inside fence; when using a planning document, marker includes plan summary: `[NN]-[Topic] [ NN / NN ] - [plan step ID] [brief summary]`
- [ ] PRMT-ST-01..05: Each prompt has objective, constraints (if implementation), verification, reasoning modes mixed only within run budget, items at or below Items
- [ ] PRMT-SQ-01..04: No contradictions, explicit dependencies, commentary documents state, verification checkpoints after every checkpoint interval plus a final checkpoint per file
- [ ] PRMT-CT-01..14: Specific objectives, negative constraints, observable verification, workflow execution vs reference distinction (execution verb = standalone without backticks, no execution verb = backticks), existing workflows leveraged, agent tools over shell for file operations, timestamp from request metadata, banned-term sweep recording
- [ ] PRMT-EX-01..03: One prompt per turn, no self-execution by writing agent, execution authority
- [ ] PRMT-HS-01: Implementation prompts include hang-safety clause
- [ ] PRMT-HS-02: Banned command list is project-specific
- [ ] PRMT-HS-03..06: Expected runtimes in the robustness card; no prompt sets a time limit or restates hang-verdict or cleanup procedures; no interactive commands
- [ ] PRMT-HS-07..08: Specific test files in verification, prior-step verification
- [ ] PRMT-HS-09: Targeted test scope — specific test files, not full suite, in implementation prompts
- [ ] PRMT-SC-08: Session anchor with absolute paths in every prompt; working-folder constraint in implementation prompts
- [ ] PRMT-HS-10: Spec-code consistency check in Verify when prompt changes code with associated spec
- [ ] PRMT-HS-11: Card `## Agent tool limits` copied from own rule; file-writing prompts reference it; no token numbers in prompts
- [ ] PRMT-CT-12: No shell commands for file search/read in prompt bodies — agent tools only
- [ ] PRMT-RB-01: Findings card designated for the sequence
- [ ] PRMT-RB-02: Findings-card directive in every implementation prompt
- [ ] PRMT-RB-03..06: Card read at startup, glitches filed before commit, entry format, card system integration
- [ ] PRMT-RB-07: Session PROBLEMS.md records deferred problems, not detailed glitch logs
- [ ] PRMT-RB-08: Fails card exists (reused or created); exactly one `Runtime check:` line per implementation prompt; final checkpoint carries the promotion line
- [ ] No unresolved `[PLACEHOLDER]` values remain in the output
- [ ] No XML comments remain in the output
- [ ] Privacy gate: no real user data leaked into the filled instance

# OUTPUT

## Compose mode

Validated `_PROMPTS_[NN]-[Topic].md` file in target location.

## From Template mode

Validated `_PROMPTS_[NN]-[Topic]-[Instance].md` file with all placeholders resolved, ready for sequential execution.

## Quality Gate

- [ ] All PRMT-* rules pass (FT-01 through FT-10, ST, SQ, CT-01 through CT-14, SC, EX-01 through EX-03, HS-01 through HS-10, RB, NM-01 through NM-04)
- [ ] Filename includes zero-padded sequence number `_PROMPTS_[NN]-[Topic].md` (PRMT-NM-03); [Topic] contains domain prefix ensuring [NN]-[Topic] uniqueness across session (PRMT-NM-04)
- [ ] Workflow call formatting: no execution verb + backticks combinations remain (PRMT-CT-08)
- [ ] Session anchor in every prompt (PRMT-SC-08): absolute session folder and working folder after Prompt Marker; working-folder constraint in implementation prompts
- [ ] Self-contained opening in every prompt (PRMT-SC-01): context-loading directive, "treat earlier conversation as compacted", step identifier
- [ ] No conversation dependency: no "the previous step" without file path (PRMT-SC-02)
- [ ] Idempotency constraints in implementation prompts (PRMT-SC-03)
- [ ] Max 10 implementation prompts per file; longer sequences continue in the next numbered file (PRMT-SC-04)
- [ ] Effort level in frontmatter, prompt count matches effort budget (PRMT-SC-05); frontmatter and per-prompt scope pass the PRMT-SC-05 model-data checks
- [ ] Planning document referenced by filename and step ID (PRMT-SC-06)
- [ ] No shell commands for file search/read in prompt bodies — agent tools only (PRMT-CT-12)
- [ ] Verification runs specific test files, not full suite, during implementation steps (PRMT-HS-09)
- [ ] Verification checkpoints after every checkpoint interval plus a final checkpoint per file (PRMT-SQ-04)
- [ ] Privacy gate applied (no real project data in examples)
- [ ] Fence depths verified (outer > deepest inner per prompt)
- [ ] **From Template mode**: Zero unresolved placeholders
- [ ] **From Template mode**: Zero remaining XML comments
- [ ] **From Template mode**: All conditional sections resolved
